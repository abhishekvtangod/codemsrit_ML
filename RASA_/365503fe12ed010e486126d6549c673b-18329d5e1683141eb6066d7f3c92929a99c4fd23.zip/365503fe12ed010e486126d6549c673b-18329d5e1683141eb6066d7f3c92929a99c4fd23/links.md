# Links for "Building a Chatbot with Rasa"

<a href='#slides-companion'>Slides companion</a>\
<a href='#links-for-hands-on-sessions'>Links for hands-on sessions</a>

## Slides companion
### Rasa NLU
[Documentation on nlu-config.yml](https://rasa.com/docs/nlu/components/) (Hint: Useful for the challenges 1 and 2) \
[How Rasa Trains - 1](https://medium.com/rasa-blog/a-new-approach-to-conversational-software-2e64a5d05f2a)\
[How Rasa Trains - 2](https://blog.rasa.com/attention-dialogue-and-learning-reusable-patterns/)

### Rasa Core
[Story data format](https://rasa.com/docs/core/stories/) (Handy for the challenges 3) \

## Links for hands-on sessions
### hands-on-1
[Rasa NLU Documentation](http://rasa.com/docs/nlu)  
[Rasa Core Documentation](http://rasa.com/docs/core)  
[Rasa Starter Pack](http://github.com/msamogh/rasa-starter-pack)

### hands-on-2
[Rasa NLU Trainer](https://rasahq.github.io/rasa-nlu-trainer/)

### hands-on-4

Your task is to build a bot to help applicants find jobs to apply for at a company, and lets applicants check their status.
we have provided you with a pair of custom actions below in the file `actions.py`. 

The bot should allow for two kinds of conversations:

> "Hi"

"hi, I'm the recruiting bot. How can I help?"

> "I'd like to know which positions are open right now"

"Are you looking for a technical or a business role?"

> "A technical one"

"ML Engineer and Solutions Engineer are the open positions."

**and** 

> "Hi, my name is Ali Park. I applied for a job and would like to know when I'll hear back"

"Hi Ali! Let me check that for you"

> "Yes, your application has been received."

To do this, you will have to: 
1. Create some NLU training data
2. Create some Rasa Core training data
3. Define a domain
4. Train your models 

i.e. you will need to code your recruiting bot from scratch using the Rasa stack.  It's suggested that you refer to the [getting started walkthrough on our website here](https://rasa.com/docs/get_started_step1/), which details the relevant steps.
